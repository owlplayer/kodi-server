import sys
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin

# ============================================
# CONFIGURACIÓN - ¡CAMBIAR AQUÍ TUS DATOS!
# ============================================
OUO_API_KEY = "LeqWa60A"  # ¡CAMBIA ESTO POR TU API KEY DE OUO.IO!
# ============================================

# Tu catálogo de películas (formato MEGA)
PELICULAS = {
    "Película de Prueba (MEGA)": "https://mega.nz/file/R79lwDiS#cmfW7zcAeWYtxqc_31YrcA90KqIoyauglf7uH2tB8jg"
    # Añade más películas aquí con el formato: "Nombre": "URL_de_MEGA"
}

# ============================================
# NO MODIFICAR NADA DEBAJO DE ESTA LÍNEA
# ============================================

# Obtener argumentos correctamente
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}

def mostrar_menu():
    """Muestra el catálogo de películas en Kodi"""
    for nombre_peli, url_mega in PELICULAS.items():
        # Crear URL de acción con los parámetros codificados
        url_accion = f"{base_url}?action=play&url={urllib.parse.quote(url_mega)}"
        
        # Crear el elemento de lista
        list_item = xbmcgui.ListItem(label=nombre_peli)
        list_item.setInfo('video', {'title': nombre_peli})
        list_item.setProperty('IsPlayable', 'true')
        
        # Añadir al menú
        xbmcplugin.addDirectoryItem(
            handle=addon_handle, 
            url=url_accion, 
            listitem=list_item, 
            isFolder=False
        )
    
    # Finalizar el listado del menú
    xbmcplugin.endOfDirectory(addon_handle)

def reproducir(url_real_mega):
    """
    Función principal de reproducción con monetización QR
    """
    # ===== PASO 1: Acortar enlace con Ouo.io =====
    url_encriptada = urllib.parse.quote(url_real_mega)
    
    # IMPORTANTE: Verifica la URL correcta de la API de Ouo.io
    # Normalmente es: https://ouo.io/api/{API_KEY}?s={URL_ENCODED}
    api_url = f"https://ouo.io/api/{OUO_API_KEY}?s={url_encriptada}"
    
    # Intentar obtener el enlace acortado
    link_acortado = url_real_mega  # Fallback: usar enlace original
    try:
        xbmc.log(f"Conectando a Ouo.io: {api_url}", xbmc.LOGINFO)
        respuesta = requests.get(api_url, timeout=10)
        
        if respuesta.status_code == 200:
            link_acortado = respuesta.text.strip()
            xbmc.log(f"Enlace acortado obtenido: {link_acortado}", xbmc.LOGINFO)
        else:
            xbmc.log(f"Error Ouo.io: Código {respuesta.status_code}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"Error al acortar URL: {str(e)}", xbmc.LOGWARNING)
    
    # ===== PASO 2: Generar código QR =====
    # Generar QR con el enlace acortado
    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={urllib.parse.quote(link_acortado)}"
    xbmc.log(f"QR URL: {qr_url}", xbmc.LOGINFO)
    
    # ===== PASO 3: Mostrar diálogo con QR y espera =====
    dialog = xbmcgui.DialogProgress()
    dialog.create(
        '🔒 ENLACE PROTEGIDO',
        'Escanea el código QR con tu móvil',
        'para apoyar al canal y ver el contenido.',
        'Tiempo restante: 20 segundos'
    )
    
    # Mostrar instrucciones más claras al usuario
    xbmcgui.Dialog().ok(
        '📱 ESCANEA EL QR', 
        '1. Escanea el código QR con tu móvil',
        '2. Verás publicidad que nos ayuda',
        '3. El contenido comenzará automáticamente'
    )
    
    # Cuenta regresiva de 20 segundos
    segundos_espera = 20
    for i in range(segundos_espera, 0, -1):
        if dialog.iscanceled():
            dialog.close()
            xbmcgui.Dialog().ok('❌', 'Reproducción cancelada')
            return
        
        # Calcular porcentaje
        porcentaje = int(((segundos_espera - i) / segundos_espera) * 100)
        
        # Actualizar el diálogo (3 líneas de texto)
        dialog.update(
            porcentaje,
            f"⏱️ Tiempo restante: {i} segundos",
            f"📱 Código QR: {qr_url[:50]}...",
            "⚡ El contenido se reproducirá automáticamente"
        )
        
        # Pausa de 1 segundo
        xbmc.sleep(1000)
    
    dialog.close()
    
    # ===== PASO 4: Reproducir contenido =====
    # Crear URL para ResolveURL
    resolve_url = f"plugin://script.module.resolveurl/?url={urllib.parse.quote(url_real_mega)}"
    
    # Crear el ListItem para la reproducción
    listitem = xbmcgui.ListItem(path=resolve_url)
    listitem.setContentLookup(False)
    listitem.setProperty('IsPlayable', 'true')
    listitem.setInfo('video', {'title': 'Cargando...'})
    
    # Enviar el elemento resuelto a Kodi
    xbmcplugin.setResolvedUrl(
        handle=addon_handle,
        succeeded=True,
        listitem=listitem
    )

# ===== ENRUTADOR DE ACCIONES =====
action = args.get('action', [None])[0] if args else None

if action is None:
    # Mostrar el menú principal
    mostrar_menu()
elif action == 'play':
    # Obtener la URL de MEGA
    url_mega = args.get('url', [None])[0]
    if url_mega:
        # Iniciar reproducción con monetización
        reproducir(url_mega)
    else:
        xbmcgui.Dialog().ok('❌ Error', 'No se pudo obtener la URL de la película')
else:
    xbmcgui.Dialog().ok('❌ Error', f'Acción desconocida: {action}')