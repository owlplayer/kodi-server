import sys
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin

# --- CONFIGURACIÓN ---
OUO_API_KEY = "LeqWa60A"
# Tu catálogo de películas (debe ser un enlace completo de MEGA con clave de descifrado)
PELICULAS = {
    "Película de Prueba (MEGA)": "https://mega.nz/file/R79lwDiS#cmfW7zcAeWYtxqc_31YrcA90KqIoyauglf7uH2tB8jg"
}
# ----------------------

base_url = sys.argv
addon_handle = int(sys.argv)
args = urllib.parse.parse_qs(sys.argv[1:])

def mostrar_menu():
    for nombre_peli, url_mega in PELICULAS.items():
        url_accion = f"{base_url}?action=play&url={urllib.parse.quote(url_mega)}"
        list_item = xbmcgui.ListItem(label=nombre_peli)
        list_item.setInfo('video', {'title': nombre_peli})
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_accion, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def reproducir(url_real_mega):
    # 1. Enviar el enlace original a la API de Ouo.io para monetizarlo
    url_encriptada = urllib.parse.quote(url_real_mega)
    api_url = f"https://ouo.io{OUO_API_KEY}?s={url_encriptada}"
    
    try:
        respuesta = requests.get(api_url, timeout=10)
        link_publicidad = respuesta.text if respuesta.status_code == 200 else url_real_mega
    except:
        link_publicidad = url_real_mega

    # 2. Generar imagen del Código QR usando una API pública limpia
    api_qr = f"https://qrserver.com{urllib.parse.quote(link_publicidad)}"
    
    # 3. Mostrar pantalla de carga con el QR
    dialogo = xbmcgui.DialogProgress()
    dialogo.create('🔒 ENLACE PROTEGIDO', 'Escanea el QR para desbloquear el streaming.')
    
    # Cuenta regresiva de 20 segundos para que el usuario interactúe en su móvil
    segundos_espera = 20
    for i in range(1, segundos_espera + 1):
        if dialogo.iscanceled():
            return
        porcentaje = int((i / segundos_espera) * 100)
        dialogo.update(porcentaje, f"Abriendo canales de streaming...\n{segundos_espera - i}s restantes.\nEscanea el link en tu pantalla para apoyar al canal.")
        xbmc.sleep(1000)
        
    dialogo.close()

    # 4. Enviar el enlace limpio de MEGA al motor de ResolveURL
    url_final_streaming = f"plugin://script.module.resolveurl/?url={url_real_mega}"
    listitem = xbmcgui.ListItem(path=url_final_streaming)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem)

# Enrutador de acciones de Kodi
action = args.get('action', [None])
if action is None:
    mostrar_menu()
elif action == 'play':
    url_mega = args.get('url', [None])
    reproducir(url_mega)
