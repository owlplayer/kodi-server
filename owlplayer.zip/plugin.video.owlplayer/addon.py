import sys
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin

# ============================================
# CONFIGURACIÓN - ¡CAMBIA TU API KEY!
# ============================================
OUO_API_KEY = "LeqWa60A"  # ¡CAMBIA ESTO!
# ============================================

PELICULAS = {
    "Película de Prueba (MEGA)": "https://mega.nz/file/R79lwDiS#cmfW7zcAeWYtxqc_31YrcA90KqIoyauglf7uH2tB8jg"
}

# ============================================

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}

def verificar_resolveurl():
    """Verifica si ResolveURL está instalado correctamente"""
    try:
        import resolveurl
        xbmc.log("ResolveURL encontrado correctamente", xbmc.LOGINFO)
        return True
    except ImportError:
        xbmc.log("ERROR: ResolveURL no está instalado", xbmc.LOGERROR)
        return False

def mostrar_menu():
    for nombre_peli, url_mega in PELICULAS.items():
        url_accion = f"{base_url}?action=play&url={urllib.parse.quote(url_mega)}"
        list_item = xbmcgui.ListItem(label=nombre_peli)
        list_item.setInfo('video', {'title': nombre_peli})
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=addon_handle, 
            url=url_accion, 
            listitem=list_item, 
            isFolder=False
        )
    xbmcplugin.endOfDirectory(addon_handle)

def reproducir(url_real_mega):
    # Verificar que ResolveURL existe
    if not verificar_resolveurl():
        xbmcgui.Dialog().ok(
            '❌ Error', 
            'ResolveURL no está instalado.',
            'Instálalo desde el repositorio oficial'
        )
        return
    
    # ===== PASO 1: Acortar enlace con Ouo.io =====
    url_encriptada = urllib.parse.quote(url_real_mega)
    # FORMATO CORRECTO PARA OUO.IO - Verifica esto en su web
    api_url = f"https://ouo.io/api/{OUO_API_KEY}?s={url_encriptada}"
    
    link_acortado = url_real_mega
    try:
        xbmc.log(f"Conectando a Ouo.io...", xbmc.LOGINFO)
        respuesta = requests.get(api_url, timeout=10)
        if respuesta.status_code == 200:
            link_acortado = respuesta.text.strip()
            xbmc.log(f"Enlace acortado: {link_acortado}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Error Ouo.io: {str(e)}", xbmc.LOGWARNING)
    
    # ===== PASO 2: Generar código QR =====
    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={urllib.parse.quote(link_acortado)}"
    
    # ===== PASO 3: Mostrar diálogo =====
    # Instrucciones previas
    xbmcgui.Dialog().ok(
        '📱 ESCANEA EL QR', 
        '1. Escanea el código QR',
        '2. Verás publicidad que nos ayuda',
        '3. El contenido comenzará automáticamente'
    )
    
    # Diálogo de espera
    dialog = xbmcgui.DialogProgress()
    dialog.create(
        '🔒 ENLACE PROTEGIDO',
        'Escanea el código QR',
        'para apoyar al canal',
        '⏱️ 20 segundos'
    )
    
    segundos_espera = 20
    for i in range(segundos_espera, 0, -1):
        if dialog.iscanceled():
            dialog.close()
            xbmcgui.Dialog().ok('❌', 'Reproducción cancelada')
            return
        
        porcentaje = int(((segundos_espera - i) / segundos_espera) * 100)
        dialog.update(
            porcentaje,
            f"⏱️ Tiempo: {i} segundos",
            f"📱 QR: {qr_url[:40]}...",
            "⚡ Listo para reproducir"
        )
        xbmc.sleep(1000)
    
    dialog.close()
    
    # ===== PASO 4: Reproducir =====
    # Usar ResolveURL para resolver el enlace de MEGA
    try:
        import resolveurl
        import resolveurl.resolvers.megaresolver
        
        # Intentar resolver el enlace
        resolved_url = resolveurl.resolve(url_real_mega)
        if resolved_url:
            xbmc.log(f"URL resuelta: {resolved_url}", xbmc.LOGINFO)
        else:
            # Si no se puede resolver, usar el enlace directo
            resolved_url = url_real_mega
            xbmc.log("Usando URL directa de MEGA", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"Error en ResolveURL: {str(e)}", xbmc.LOGERROR)
        resolved_url = url_real_mega
    
    # Crear ListItem
    listitem = xbmcgui.ListItem(path=resolved_url)
    listitem.setContentLookup(False)
    listitem.setProperty('IsPlayable', 'true')
    
    # Enviar a Kodi
    xbmcplugin.setResolvedUrl(
        handle=addon_handle,
        succeeded=True,
        listitem=listitem
    )

# ===== ENRUTADOR =====
action = args.get('action', [None])[0] if args else None

if action is None:
    mostrar_menu()
elif action == 'play':
    url_mega = args.get('url', [None])[0]
    if url_mega:
        reproducir(url_mega)
    else:
        xbmcgui.Dialog().ok('❌ Error', 'No se pudo obtener la URL')
else:
    xbmcgui.Dialog().ok('❌ Error', f'Acción desconocida: {action}')